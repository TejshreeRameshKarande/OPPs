#include<iostream>
using namespace std;

int main()
{
	int a=10,b=20;
	float res;
	
	res=a+b;
	cout<<"\naddition is "<<res;
	
	res=a-b;
	cout<<"\nsubstraction is "<<res;
	
	res=a*b;
	cout<<"\nmultiplication is "<<res;
	
	res=(float)a/b;
	cout<<"\ndivision is "<<res;
	
	res=a%b;
	cout<<"\nmod is "<<res;
	
}
